
public class Main{


	public static void main(String[] args){
	
		User firstUser=new User();
		User secondUser=new User();
		User thirdUser=new User();
		
		firstUser.ricarica(5);
		firstUser.chiamata(2);
		System.out.println(firstUser.getCredito()+" "+firstUser.getNumeroChiamate());
	}


}