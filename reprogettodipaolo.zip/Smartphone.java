public interface Smartphone{
	float carica=0;
	int numChiamate=0;
	public void ricarica(float importo);
	public void chiamata(int minutsi);
}