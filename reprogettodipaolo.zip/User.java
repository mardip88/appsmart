public class User implements Smartphone{
	
	private float importo;
	private int minuti;
	private float credito;
	private int chiamate;
	private final float TARIFFA=0.20f;
	float carica;
	int numChiamate;
	public void ricarica(float importo){
		this.importo+=importo;
	}

	public void chiamata(int minuti){
		if(this.credito>=0.20){
			this.minuti+=minuti;
			float costo=this.minuti*this.TARIFFA;
			this.credito-=costo;
			this.chiamate++;
		}else{
			System.out.println("Non puoi effettuare la chiamata. Effettua una ricarica");
		}
	}
	
	public float getCredito(){return this.credito;}
	
	public int getNumeroChiamate(){return this.chiamate;}
	
	public void azzeraChiamate(){this.chiamate=0;}
}